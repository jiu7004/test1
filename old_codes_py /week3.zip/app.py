from flask import Flask, request, jsonify, render_template
from flask_mysqldb import MySQL

app = Flask(__name__)

# MySQL configurations
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'mina7004m!'
app.config['MYSQL_DB'] = 'test'

mysql = MySQL(app)

@app.route('/post', methods=['POST'])
def add_post():
    title = request.form['title']
    content = request.form['content']


# @app.route('/posts')
# def show_posts():
#     cur = mysql.connection.cursor()
#     cur.execute("SELECT * FROM boardT")
#     posts = cur.fetchall()
#     cur.close()
#     return render_template('post_list.html', posts=posts)
#
#
# @app.route('/post', methods=['POST'])
# def add_post():
#     title = request.form['title']
#     content = request.form['content']
#     cur = mysql.connection.cursor()
#     cur.execute("INSERT INTO boardT(title, content) VALUES (%s, %s)", (title, content))
#     mysql.connection.commit()
#     cur.close()
#     return jsonify({'message': 'Post created successfully'}), 201
#
#
# @app.route('/posts', methods=['GET'])
# def get_posts():
#     cur = mysql.connection.cursor()
#     cur.execute("SELECT * FROM boardT")
#     rows = cur.fetchall()
#     cur.close()
#     return jsonify(rows)
#
#
# @app.route('/post/<int:id>', methods=['PUT'])
# def update_post(id):
#     title = request.form['title']
#     content = request.form['content']
#     cur = mysql.connection.cursor()
#     cur.execute("UPDATE boardT SET title = %s, content = %s WHERE id = %s", (title, content, id))
#     mysql.connection.commit()
#     cur.close()
#     return jsonify({'message': 'Post updated successfully'})
#
#
# @app.route('/post/<int:id>', methods=['DELETE'])
# def delete_post(id):
#     cur = mysql.connection.cursor()
#     cur.execute("DELETE FROM boardT WHERE id = %s", [id])
#     mysql.connection.commit()
#     cur.close()
#     return jsonify({'message': 'Post deleted successfully'})
#

# @app.route('/search', methods=['GET'])
# def search():
#     keyword = request.args.get('keyword', '')
#     search_by = request.args.get('by', 'all')  # 'title', 'content', or 'all'
#
#     query = "SELECT * FROM boardT WHERE"
#     if search_by == 'title':
#         query += " title LIKE %s"
#     elif search_by == 'content':
#         query += " content LIKE %s"
#     else:
#         query += " title LIKE %s OR content LIKE %s"
#
#     cur = mysql.connection.cursor()
#     if search_by in ['title', 'content']:
#         cur.execute(query, [f"%{keyword}%"])
#     else:
#         cur.execute(query, [f"%{keyword}%", f"%{keyword}%"])
#
#     rows = cur.fetchall()
#     cur.close()
#     return jsonify(rows)


if __name__ == '__main__':
    app.run(debug=True)
