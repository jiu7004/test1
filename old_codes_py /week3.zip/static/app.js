// static/app.js
console.log("JavaScript is working!");
<script src="{{ url_for('static', filename='app.js') }}"></script>
